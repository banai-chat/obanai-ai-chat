# Obanai AI Chat

A mobile-friendly Arabic roleplay chat for Obanai Iguro, with a server-side OpenAI-compatible chat model and persistent story memory.

## Requirements
- Node.js 20+
- An API key for a model provider compatible with the OpenAI Chat Completions API

## Run locally
1. Install Node.js.
2. In this folder, run `npm install`.
3. Set `OPENAI_API_KEY` as an environment variable. Optional: set `OPENAI_MODEL` (default `gpt-4.1-mini`).
4. Run `npm start`.
5. Open `http://localhost:3000`.

Never put the API key into `index.html` or commit it to source control.

## Deploy
Deploy this folder to a Node.js host that supports persistent disk storage. Set `OPENAI_API_KEY` in the host's environment/secrets settings. If the host has ephemeral storage, replace `data/*.json` storage with a persistent database before relying on long-term memories.

## Note
API calls may incur provider charges. Set spending limits with the provider. This is a fan-made roleplay project, not an official Demon Slayer product.
